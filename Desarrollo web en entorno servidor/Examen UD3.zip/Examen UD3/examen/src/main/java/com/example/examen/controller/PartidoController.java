package com.example.examen.controller;



import com.example.examen.model.Partido;
import jakarta.servlet.http.Part;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Controller
public class PartidoController {

    List<Partido> listaPartidos=new ArrayList<>(Arrays.asList(
            new Partido(1,"Patatas","Tomates","Finalizado","3-2"),
            new Partido(2,"Tiburones","Aguilas","Pendiente",""),
            new Partido(3,"Mengibar","Andujar","Pendiente","")
    ));

    public List<Partido> getListaPartidos() {
        return listaPartidos;
    }

    @GetMapping("/")
    public String verTorneo(Model model,Partido partido){
        for(Partido p : listaPartidos){
            model.addAttribute("partido",p);
        }
        return "torneo";
    }

    @GetMapping("/partido/{jugador}")
    public String verPartidoJugador(@PathVariable String jugador,Partido partido,Model model){
        for(Partido p : listaPartidos){
            if(p.getNombreEquipo().equalsIgnoreCase(jugador) || p.getRival().equalsIgnoreCase(jugador)){
                model.addAttribute("mostrarPartido",p);
                break;
            }
            else {
                model.addAttribute("error","No hay partidos con ese jugador");
            }
        }
        return "partido";
    }
    @GetMapping("/panel")
    public String panelAlbitraje(Partido partido, Model model){
        return "panel";
    }
    @PostMapping("/buscar/{id}")
    public String buscarPartido(@RequestBody int id,Model model, Partido partido){
        partido=new Partido();
        for(Partido p : listaPartidos){
            if(p.getIdentificador()==id){
                model.addAttribute("mostrarPartido",p);
                break;
            }
        }
        return "partido";
    }

}
