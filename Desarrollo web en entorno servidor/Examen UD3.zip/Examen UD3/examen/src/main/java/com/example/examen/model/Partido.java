package com.example.examen.model;

public class Partido {
    private int identificador;
    private String nombreEquipo;
    private String rival;
    private String estado;
    private String resultado;

    public Partido() {
    }

    public Partido(int identificador, String nombreEquipo, String rival, String estado, String resultado) {
        this.identificador = identificador;
        this.nombreEquipo = nombreEquipo;
        this.rival = rival;
        this.estado = estado;
        this.resultado = resultado;
    }

    public int getIdentificador() {
        return identificador;
    }

    public void setIdentificador(int identificador) {
        this.identificador = identificador;
    }

    public String getNombreEquipo() {
        return nombreEquipo;
    }

    public void setNombreEquipo(String nombreEquipo) {
        this.nombreEquipo = nombreEquipo;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public String getRival() {
        return rival;
    }

    public void setRival(String rival) {
        this.rival = rival;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
