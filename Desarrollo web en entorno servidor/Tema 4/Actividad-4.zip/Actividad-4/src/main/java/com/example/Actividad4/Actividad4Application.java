package com.example.Actividad4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Actividad4Application {

	public static void main(String[] args) {
		SpringApplication.run(Actividad4Application.class, args);
	}

}
