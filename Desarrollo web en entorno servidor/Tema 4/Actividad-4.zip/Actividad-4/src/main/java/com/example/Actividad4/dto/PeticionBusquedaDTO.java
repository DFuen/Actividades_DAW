package com.example.Actividad4.dto;

public class PeticionBusquedaDTO {
    private String nombre;


    public String getNombre() {return nombre;}
    public void setNombre(String nombre) {this.nombre = nombre;}
}
