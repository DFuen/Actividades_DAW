package com.example.Actividad4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Actividad4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
